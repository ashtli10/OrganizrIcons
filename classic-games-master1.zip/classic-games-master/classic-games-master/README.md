classic-games
=============

HTML5 recreation of classic games. Play online: https://consto.uk/classic-games

[![](screenshot.png)](https://consto.uk/classic-games)

### Games

* 2048
* Asteroids
* Flappybird
* Fractal
* Minesweeper
* Pong
* Snake
